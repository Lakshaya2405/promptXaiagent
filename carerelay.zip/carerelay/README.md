# CareRelay

**Every handover matters. Every care task remembered.**

CareRelay helps families and paid carers hand over care without losing anything important. A handover note becomes a card with a summary, a "read first" list of warnings, and tasks that have owners and due times. Each card can be exported as an open JSON file, and public sources can be looked up through the TinyFish Search API.

## How it supports open innovation

- **Open format.** Handovers export as documented JSON (see [docs/handover-schema.md](docs/handover-schema.md)), so clinics, community groups, and other apps can read and reuse them.
- **Open source.** The code is MIT licensed. Contributions of code, care templates, and translations are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).
- **Shared knowledge.** Families can pass handover files to each other and to new carers, instead of rebuilding what they know from memory.

## What works today

- Create handover cards from a free-text note. Lines starting with `-` become tasks. Lines with words such as "warning" or "do not" are flagged as warnings.
- Assign an owner and a due time to each task. Overdue open tasks are highlighted.
- Keep cards in the browser's local storage. Nothing leaves the device unless you search.
- Export a card as JSON, and import a card from a file.
- Look up public sources through a server-side function that calls the TinyFish Search API. The API key is never sent to the browser.

## Known limits (be honest with users)

- **Structuring is rule-based, not a language model.** It is predictable and easy to test, but it will miss some phrasing. Read the cards before relying on them.
- **No reminders outside the page.** Overdue tasks are highlighted when you open the app. Push notifications are future work.
- **No accounts or sync yet.** Cards live in one browser. Export and import to move them.
- **Search results are not medical advice.** The lookup returns links to check yourself.

## Tech stack

- React 18 and Vite, for the interface and build.
- Plain JavaScript modules for the structuring rules and file format, with tests on Node's built-in test runner.
- A Vercel serverless function (`api/search.js`) that proxies to the TinyFish Search API.

## Run it locally

Requirements: Node.js 18 or newer.

```bash
npm install
npm test
npm run dev
```

Open the URL Vite prints. The source lookup needs the serverless function, so to test it locally use:

```bash
cp .env.example .env.local      # then add your TINYFISH_API_KEY
npx vercel dev
```

## Environment variables

| Name | Required | Purpose |
| --- | --- | --- |
| `TINYFISH_API_KEY` | For source lookup | Create a key at https://agent.tinyfish.ai/api-keys. Keep it secret. |
| `TINYFISH_LOCATION` | No | Two-letter country code to geo-target results, such as `US` or `IN`. |

## Push to GitHub

This project includes a git repository with an initial commit. To publish it:

1. Create an empty repository on GitHub (no README, no license, no .gitignore, since those already exist here).
2. From the project folder, set your identity and point to the repository:

   ```bash
   git config user.name "Your Name"
   git config user.email "you@example.com"
   git commit --amend --reset-author --no-edit
   git remote add origin https://github.com/YOUR-USERNAME/carerelay.git
   git push -u origin main
   ```

3. Add the repository description and topics on GitHub, for example `open-innovation`, `caregiving`, `react`, `vite`, `tinyfish`.

## Deploy on Vercel

1. Go to https://vercel.com/new and import the GitHub repository.
2. Vercel detects Vite automatically. Keep the default build command `npm run build` and output directory `dist`.
3. Under **Environment Variables**, add `TINYFISH_API_KEY` (and `TINYFISH_LOCATION` if you want it). Apply them to Production and Preview.
4. Click **Deploy**. Your live URL appears when the build finishes.
5. Check it: create a handover, export it, import it back, and run a source lookup.

Every push to `main` redeploys automatically.

## Project layout

```
api/search.js               Vercel function: TinyFish Search proxy
src/App.jsx                 Page layout, state, import
src/components/             Form, handover card, source lookup
src/lib/structure.js        Note structuring rules (tested)
src/lib/schema.js           File export and import (tested)
src/lib/storage.js          Local storage
docs/handover-schema.md     The open file format
```

## Future scope

- Structuring with a language model that can be switched on by configuration, with the current rules kept as a fallback.
- Browser notifications and shared family accounts.
- A library of community care templates that people can fork and improve.
- Translations for Hindi and other Indian languages.

## License

MIT. See [LICENSE](LICENSE).
