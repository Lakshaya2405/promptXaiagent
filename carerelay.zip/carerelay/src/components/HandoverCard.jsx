import ResourceLookup from './ResourceLookup.jsx';
import { exportHandover } from '../lib/schema.js';

export default function HandoverCard({ handover, onChange, onDelete }) {
  const now = Date.now();
  const openCount = handover.tasks.filter((t) => t.status === 'open').length;

  function updateTask(id, patch) {
    onChange({
      ...handover,
      tasks: handover.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    });
  }

  function download() {
    const blob = new Blob([exportHandover(handover)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `handover-${handover.id}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <article className="card handover">
      <header className="handover-head">
        <div>
          <h2>{handover.recipient}</h2>
          <p className="meta">
            {handover.caregiver ? `From ${handover.caregiver} · ` : ''}
            {openCount} open {openCount === 1 ? 'task' : 'tasks'}
          </p>
        </div>
        <button type="button" className="ghost danger" onClick={onDelete}>Delete</button>
      </header>

      <p className="summary">{handover.summary}</p>

      {handover.warnings.length > 0 && (
        <div className="warnings" role="note">
          <h3>Read first</h3>
          <ul>
            {handover.warnings.map((w, i) => <li key={i}>{w}</li>)}
          </ul>
        </div>
      )}

      <h3>Tasks</h3>
      {handover.tasks.length === 0 && <p className="hint">No tasks in this note.</p>}
      <ul className="tasks">
        {handover.tasks.map((t) => {
          const overdue = t.status === 'open' && t.due && new Date(t.due).getTime() < now;
          return (
            <li key={t.id} className={`task ${t.status === 'done' ? 'is-done' : ''} ${overdue ? 'is-overdue' : ''}`}>
              <label className="task-main">
                <input
                  type="checkbox"
                  checked={t.status === 'done'}
                  onChange={(e) => updateTask(t.id, { status: e.target.checked ? 'done' : 'open' })}
                />
                <span>{t.text}</span>
              </label>
              <div className="task-fields">
                <label>
                  Owner
                  <input value={t.owner} placeholder="Who does this?" onChange={(e) => updateTask(t.id, { owner: e.target.value })} />
                </label>
                <label>
                  Due
                  <input type="datetime-local" value={t.due} onChange={(e) => updateTask(t.id, { due: e.target.value })} />
                </label>
              </div>
              {overdue && <p className="overdue-note">Overdue</p>}
            </li>
          );
        })}
      </ul>

      <ResourceLookup />

      <footer className="handover-foot">
        <button type="button" className="ghost" onClick={download}>Export as JSON</button>
      </footer>
    </article>
  );
}
