import { useState } from 'react';

// Looks up public sources through the server-side /api/search function, so the
// TinyFish key never reaches the browser. Results are links to check yourself.
export default function ResourceLookup() {
  const [query, setQuery] = useState('');
  const [state, setState] = useState({ status: 'idle', results: [], message: '' });

  async function lookup(event) {
    event.preventDefault();
    const q = query.trim();
    if (!q) return;
    setState({ status: 'loading', results: [], message: '' });
    try {
      const res = await fetch(`/api/search?query=${encodeURIComponent(q)}`);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setState({ status: 'error', results: [], message: data.error || `Lookup failed (${res.status}).` });
        return;
      }
      setState({
        status: 'done',
        results: data.results ?? [],
        message: (data.results ?? []).length ? '' : 'No results found. Try different words.',
      });
    } catch {
      setState({
        status: 'error',
        results: [],
        message: 'Could not reach the lookup service. Locally, run the app with vercel dev.',
      });
    }
  }

  return (
    <section className="lookup" aria-label="Look up public sources">
      <h3>Look up sources</h3>
      <form className="lookup-form" onSubmit={lookup}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. blood pressure tablet side effects"
          aria-label="Search query"
          maxLength={300}
        />
        <button type="submit" disabled={state.status === 'loading'}>
          {state.status === 'loading' ? 'Searching…' : 'Search'}
        </button>
      </form>
      {state.message && <p className={state.status === 'error' ? 'error' : 'hint'}>{state.message}</p>}
      {state.results.length > 0 && (
        <ol className="results">
          {state.results.map((r) => (
            <li key={r.url}>
              <a href={r.url} target="_blank" rel="noopener noreferrer">{r.title}</a>
              <span className="site">{r.site_name}</span>
              {r.snippet && <p>{r.snippet}</p>}
            </li>
          ))}
        </ol>
      )}
      <p className="hint">These are links to check yourself, not medical advice. Confirm anything important with a doctor or pharmacist.</p>
    </section>
  );
}
