import { useState } from 'react';

export default function HandoverForm({ onCreate }) {
  const [recipient, setRecipient] = useState('');
  const [caregiver, setCaregiver] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    if (!recipient.trim()) {
      setError('Add the name of the person receiving care.');
      return;
    }
    if (!note.trim()) {
      setError('Write a short handover note.');
      return;
    }
    setError('');
    onCreate({ recipient: recipient.trim(), caregiver: caregiver.trim(), note });
    setNote('');
  }

  return (
    <form className="card form" onSubmit={submit} noValidate>
      <h2>New handover</h2>

      <div className="row">
        <label>
          Person receiving care
          <input value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder="e.g. Ramesh" />
        </label>
        <label>
          Handing over from
          <input value={caregiver} onChange={(e) => setCaregiver(e.target.value)} placeholder="e.g. Priya" />
        </label>
      </div>

      <label>
        Handover note
        <textarea
          rows={7}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder={'Describe the shift in plain words.\n- Give evening medicine at 8pm\n- Refill the blood pressure tablets\nWarning: do not give ibuprofen'}
        />
      </label>
      <p className="hint">Lines starting with - become tasks. Lines with words like warning or do not are flagged as warnings.</p>

      {error && <p className="error" role="alert">{error}</p>}

      <button type="submit" className="primary">Create handover card</button>
    </form>
  );
}
