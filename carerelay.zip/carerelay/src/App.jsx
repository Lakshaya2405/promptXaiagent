import { useEffect, useState } from 'react';
import HandoverForm from './components/HandoverForm.jsx';
import HandoverCard from './components/HandoverCard.jsx';
import { loadHandovers, saveHandovers } from './lib/storage.js';
import { structureHandover, makeId } from './lib/structure.js';
import { importHandover } from './lib/schema.js';

export default function App() {
  const [handovers, setHandovers] = useState(() => loadHandovers());
  const [notice, setNotice] = useState('');

  useEffect(() => {
    saveHandovers(handovers);
  }, [handovers]);

  function createHandover({ recipient, caregiver, note }) {
    const { summary, tasks, warnings } = structureHandover(note);
    const card = {
      id: makeId(),
      recipient,
      caregiver,
      summary,
      tasks,
      warnings,
      createdAt: new Date().toISOString(),
    };
    setHandovers((prev) => [card, ...prev]);
    setNotice('Handover card created.');
  }

  function updateHandover(updated) {
    setHandovers((prev) => prev.map((h) => (h.id === updated.id ? updated : h)));
  }

  function deleteHandover(id) {
    setHandovers((prev) => prev.filter((h) => h.id !== id));
    setNotice('Handover deleted.');
  }

  async function importFile(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    const result = importHandover(await file.text());
    if (!result.ok) {
      setNotice(`Import failed: ${result.errors.join('; ')}`);
      return;
    }
    // A new id avoids clashing with a card that already exists on this device.
    const card = { ...result.handover, id: makeId() };
    setHandovers((prev) => [card, ...prev]);
    setNotice('Handover imported.');
  }

  return (
    <div className="app">
      <header className="site-header">
        <div>
          <h1>CareRelay</h1>
          <p className="tagline">Every handover matters. Every care task remembered.</p>
        </div>
        <label className="button ghost">
          Import handover file
          <input type="file" accept="application/json,.json" onChange={importFile} hidden />
        </label>
      </header>

      <p className="notice" role="status" aria-live="polite">{notice}</p>

      <main className="layout">
        <section aria-label="Create a handover">
          <HandoverForm onCreate={createHandover} />
        </section>

        <section aria-label="Handover cards" className="cards">
          {handovers.length === 0 && (
            <p className="empty">No handovers yet. Write a note on the left to create your first card.</p>
          )}
          {handovers.map((h) => (
            <HandoverCard
              key={h.id}
              handover={h}
              onChange={updateHandover}
              onDelete={() => deleteHandover(h.id)}
            />
          ))}
        </section>
      </main>

      <footer className="site-footer">
        <p>
          Open source under the MIT license. Handover files use the open format in{' '}
          <code>docs/handover-schema.md</code>.
        </p>
      </footer>
    </div>
  );
}
