# Contributing to CareRelay

Thanks for helping. CareRelay is meant to be shared, so contributions of code, templates, and care workflows are all welcome.

## Getting set up

1. Fork the repository and clone your fork.
2. Install dependencies with `npm install`.
3. Run the tests with `npm test`.
4. Start the app with `npm run dev`, or `vercel dev` if you want the source lookup API running locally.

## Before you open a pull request

- Run `npm test` and `npm run build`. Both must pass.
- Keep changes focused. One feature or fix per pull request.
- Never commit API keys, real patient names, or personal health information. Use made-up examples in tests and screenshots.
- If you change the handover file format, update `docs/handover-schema.md` and bump the version number.

## Ideas that help most

- Better note structuring rules, with test cases that show what each rule should catch.
- Shared care templates for common routines (post-surgery recovery, dementia care, elder check-ins).
- Accessibility fixes, translations, and testing with real caregivers.

## Code of conduct

Be kind, assume good intent, and keep discussion focused on the care work the project is trying to improve.
