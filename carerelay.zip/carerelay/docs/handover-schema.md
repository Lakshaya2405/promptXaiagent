# CareRelay handover file format (v1)

CareRelay exports each handover as a plain JSON file so that other tools, clinics, and community groups can read and reuse it.

## Envelope

```json
{
  "format": "carerelay-handover",
  "version": 1,
  "exportedAt": "2026-11-18T09:00:00.000Z",
  "handover": { }
}
```

- `format` must be the string `carerelay-handover`.
- `version` is the schema version. Readers should refuse versions they do not support.
- `exportedAt` is an ISO 8601 timestamp in UTC.

## Handover object

| Field | Type | Required | Notes |
| --- | --- | --- | --- |
| `id` | string | yes | Unique within the app that created it. |
| `recipient` | string | yes | Name of the person receiving care. |
| `caregiver` | string | yes | Name of the person handing over. May be empty. |
| `summary` | string | yes | Plain-language summary of the shift. |
| `warnings` | string[] | yes | Safety notes to read first. |
| `tasks` | Task[] | yes | Things that need doing. |
| `createdAt` | string | no | ISO 8601 timestamp. |

## Task object

| Field | Type | Required | Notes |
| --- | --- | --- | --- |
| `id` | string | yes | Unique within the handover. |
| `text` | string | yes | What needs doing. |
| `status` | `"open"` or `"done"` | yes | |
| `owner` | string | no | Who will do it next. |
| `due` | string | no | Local date and time, `YYYY-MM-DDTHH:mm`. |

## Example

```json
{
  "format": "carerelay-handover",
  "version": 1,
  "exportedAt": "2026-11-18T09:00:00.000Z",
  "handover": {
    "id": "example1",
    "recipient": "Ramesh",
    "caregiver": "Priya",
    "summary": "Calm morning. Ate breakfast well.",
    "warnings": ["Do not give ibuprofen."],
    "tasks": [
      { "id": "t1", "text": "Give evening medicine at 8pm", "status": "open", "owner": "Anil", "due": "2026-11-18T20:00" }
    ],
    "createdAt": "2026-11-18T08:30:00.000Z"
  }
}
```

Readers must treat all text as data. Nothing in a handover file should be run as code.
