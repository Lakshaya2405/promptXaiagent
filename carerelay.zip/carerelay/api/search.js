// Vercel serverless function. Proxies a search to the TinyFish Search API so the
// API key stays on the server. Docs: https://docs.tinyfish.ai/search-api
const TINYFISH_SEARCH_URL = 'https://api.search.tinyfish.ai';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const apiKey = process.env.TINYFISH_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: 'Source lookup is not configured on this server.' });
  }

  const query = String(req.query.query ?? '').trim();
  if (!query || query.length > 300) {
    return res.status(400).json({ error: 'Enter a search of 1 to 300 characters.' });
  }

  const url = new URL(TINYFISH_SEARCH_URL);
  url.searchParams.set('query', query);
  if (process.env.TINYFISH_LOCATION) {
    url.searchParams.set('location', process.env.TINYFISH_LOCATION);
  }

  let upstream;
  try {
    upstream = await fetch(url, {
      headers: { 'X-API-Key': apiKey },
      signal: AbortSignal.timeout(10000),
    });
  } catch {
    return res.status(502).json({ error: 'The search service did not respond in time.' });
  }

  if (!upstream.ok) {
    const status = upstream.status === 429 ? 429 : 502;
    const message = upstream.status === 429
      ? 'Search limit reached. Try again later.'
      : `Search service returned ${upstream.status}.`;
    return res.status(status).json({ error: message });
  }

  const data = await upstream.json();
  const results = (data.results ?? []).slice(0, 5).map((r) => ({
    position: r.position,
    title: r.title,
    url: r.url,
    site_name: r.site_name,
    snippet: r.snippet,
  }));

  res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');
  return res.status(200).json({ query, results });
}
